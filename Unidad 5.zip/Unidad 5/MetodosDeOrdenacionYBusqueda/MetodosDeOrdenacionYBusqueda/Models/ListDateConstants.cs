﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetodosDeOrdenacionYBusqueda.Models
{
    public class userDateConstants
    {
        public static List<User> ListaUsuario = new List<User>()
        {
           
             new User(){id=2,Nombre="Charly",edad=80},
              new User(){id=3,Nombre="Fonseca",edad=18},
               new User(){id=1,Nombre="Hector",edad=25},
        };
    }
}
